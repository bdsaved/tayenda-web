var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/create/route.js")
R.c("server/chunks/[root-of-the-server]__61fb2713._.js")
R.c("server/chunks/2f573_bcryptjs_index_6869504d.js")
R.c("server/chunks/[root-of-the-server]__2426ad1e._.js")
R.c("server/chunks/[root-of-the-server]__2f9cc72e._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_create_route_actions_3424e3e9.js")
R.m(2071)
module.exports=R.m(2071).exports
