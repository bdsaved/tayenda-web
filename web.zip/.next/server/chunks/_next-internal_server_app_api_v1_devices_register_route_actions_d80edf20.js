module.exports=[31270,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_devices_register_route_actions_d80edf20.js.map