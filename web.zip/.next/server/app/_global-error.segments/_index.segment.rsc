1:"$Sreact.fragment"
2:I[83296,["/_next/static/chunks/9818d34f8f582e82.js","/_next/static/chunks/daae3648992045b6.js"],"default"]
3:I[8857,["/_next/static/chunks/9818d34f8f582e82.js","/_next/static/chunks/daae3648992045b6.js"],"default"]
0:{"buildId":"8gwBcYa2UzL74WvKkrLMK","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
