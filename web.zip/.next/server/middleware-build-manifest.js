globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0ca7ebbebe1b66cf.js",
    "static/chunks/ad7755117b32d2af.js",
    "static/chunks/003bb12413617b30.js",
    "static/chunks/ced0f721505bb0ce.js",
    "static/chunks/turbopack-93ca66a7bd44465f.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];