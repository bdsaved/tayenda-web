var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/trips/[tripId]/finalize/route.js")
R.c("server/chunks/[root-of-the-server]__a03f91f0._.js")
R.c("server/chunks/[root-of-the-server]__2426ad1e._.js")
R.c("server/chunks/[root-of-the-server]__2f9cc72e._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_trips_[tripId]_finalize_route_actions_1013be30.js")
R.m(18165)
module.exports=R.m(18165).exports
