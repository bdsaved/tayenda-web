var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/trips/[tripId]/chunks/route.js")
R.c("server/chunks/[root-of-the-server]__f8fc77da._.js")
R.c("server/chunks/[root-of-the-server]__2426ad1e._.js")
R.c("server/chunks/[root-of-the-server]__2f9cc72e._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_trips_[tripId]_chunks_route_actions_be7bc780.js")
R.m(99803)
module.exports=R.m(99803).exports
