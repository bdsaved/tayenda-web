var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/trips/manifest/route.js")
R.c("server/chunks/[root-of-the-server]__fdd92275._.js")
R.c("server/chunks/[root-of-the-server]__2426ad1e._.js")
R.c("server/chunks/[root-of-the-server]__2f9cc72e._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_trips_manifest_route_actions_01ff5f77.js")
R.m(92598)
module.exports=R.m(92598).exports
