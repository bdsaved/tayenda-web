var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/devices/register/route.js")
R.c("server/chunks/[root-of-the-server]__8ffa70b8._.js")
R.c("server/chunks/[root-of-the-server]__2426ad1e._.js")
R.c("server/chunks/[root-of-the-server]__2f9cc72e._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_devices_register_route_actions_d80edf20.js")
R.m(97930)
module.exports=R.m(97930).exports
