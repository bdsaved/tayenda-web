module.exports=[49550,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_trips_%5BtripId%5D_chunks_route_actions_be7bc780.js.map