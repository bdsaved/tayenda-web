1:"$Sreact.fragment"
2:I[87801,["/_next/static/chunks/9818d34f8f582e82.js","/_next/static/chunks/daae3648992045b6.js"],"ViewportBoundary"]
3:I[87801,["/_next/static/chunks/9818d34f8f582e82.js","/_next/static/chunks/daae3648992045b6.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[34476,["/_next/static/chunks/9818d34f8f582e82.js","/_next/static/chunks/daae3648992045b6.js"],"IconMark"]
0:{"buildId":"8gwBcYa2UzL74WvKkrLMK","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
