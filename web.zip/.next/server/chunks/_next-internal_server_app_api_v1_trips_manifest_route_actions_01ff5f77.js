module.exports=[77583,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_trips_manifest_route_actions_01ff5f77.js.map