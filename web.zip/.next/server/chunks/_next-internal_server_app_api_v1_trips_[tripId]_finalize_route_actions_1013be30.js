module.exports=[10672,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_trips_%5BtripId%5D_finalize_route_actions_1013be30.js.map