var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_b01ab6e1._.js")
R.c("server/chunks/[root-of-the-server]__2426ad1e._.js")
R.c("server/chunks/a2001_next_dist_esm_build_templates_app-route_2b1f9998.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_353150a5.js")
R.m(24704)
module.exports=R.m(24704).exports
